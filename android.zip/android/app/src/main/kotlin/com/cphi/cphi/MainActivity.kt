package com.cphi.cphi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
